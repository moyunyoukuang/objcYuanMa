//
//  main.m
//  LGCallocTest
//
//  Created by cooci on 2019/2/7.
//
struct LGStruct1 {
    char a;     // 1 + 7
    double b;   // 8
    int c;      // 4
    short d;    // 2 + 2
} MyStruct1;

struct LGStruct2 {
    double b;   // 8
    char a;     // 1 + 7
    int c;      // 4
    short d;    // 2
} MyStruct2;


#import <Foundation/Foundation.h>
#import <malloc/malloc.h>
int main(int argc, const char * argv[]) {
    @autoreleasepool {
		
		void *p = calloc(1, 500);
//		NSLog(@"%lu",malloc_size(p));
//		NSLog(@"%lu - %lu",class_getInstanceSize([p class]),malloc_size((__bridge const void *)(p)));
//		NSLog(@"%lu-%lu",sizeof(MyStruct1),sizeof(MyStruct2));
		
    }
    return 0;
}
