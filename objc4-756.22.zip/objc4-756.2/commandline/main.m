//
//  main.m
//  commandline
//
//  Created by BLbrain on 2019/12/17.
//

#import <Foundation/Foundation.h>

//#import <objc/runtime.h>
//#import <objc/NSObject.h>
#include "NSObject.h"
#import "NSObject.h"
int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
//        NSLog(@"Hello, World!");
        
//        xcode 11 的 Target 需要处理
//        hopper DEBUG
        
        
//        fixupMessageRef(message_ref_t *msg)
//        {
//            msg->sel = sel_registerName((const char *)msg->sel);
//
//            if (msg->imp == &objc_msgSend_fixup) {
//                if (msg->sel == SEL_alloc) {
//                    msg->imp = (IMP)&objc_alloc;
        
        NSObject * person = [[NSObject alloc] init];
        
        
        
        NSLog(@"Hello, World!%@",person);
    }
    return 0;
}
